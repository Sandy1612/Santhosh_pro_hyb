package com.emp.exceptions;

public class AccountException extends Exception {

	public AccountException(Exception e){
		
		System.out.println(e);
		
	}
}
