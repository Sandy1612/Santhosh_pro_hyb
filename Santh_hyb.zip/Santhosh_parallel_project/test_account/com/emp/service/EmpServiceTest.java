package com.emp.service;

import static org.junit.Assert.*;

import org.junit.Test;

public class EmpServiceTest {

	@Test
	public void test() {
		
	}

}
