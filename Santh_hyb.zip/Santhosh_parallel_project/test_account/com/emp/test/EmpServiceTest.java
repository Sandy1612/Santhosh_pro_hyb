package com.emp.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class EmpServiceTest {

	@Test
	public void testCreateAccount() {
		fail("Not yet implemented");
	}

	@Test
	public void testShowBalance() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeposite() {
		fail("Not yet implemented");
	}

	@Test
	public void testWithdraw() {
		fail("Not yet implemented");
	}

	@Test
	public void testPrintTransaction() {
		fail("Not yet implemented");
	}

}
